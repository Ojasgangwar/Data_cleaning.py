# Titanic Interactive Dashboard (VS Code)

A browser-based interactive dashboard for a Titanic EDA project. It has KPI cards, charts, and filters that recalculate from the currently selected rows.

## Files
- `index.html` — dashboard source (HTML, CSS, JavaScript)
- `README.md` — setup and use instructions

## Run
1. Extract the ZIP.
2. Open the folder in Visual Studio Code.
3. Open `index.html`.
4. Use Live Server, or open the HTML file directly in a browser.
5. Upload your `cleaned_titanic.csv` using the file picker at the top.

## Expected columns
The dashboard supports common Titanic column names, including:
- `Survived` (required; 0 = did not survive, 1 = survived)
- `Sex` / `Gender`
- `Pclass` / `Passenger Class`
- `Embarked`
- `Age`
- `Fare`

It also accepts a `Survival Status` column with labels such as `Survived` and `Did Not Survive`.

## Important
The initial demo view is illustrative, not the official Titanic dataset. Upload the full Titanic CSV for accurate values. The common Kaggle `train.csv` has 891 rows. When the dataset is loaded, KPIs, charts, filters, and insight text are calculated from the uploaded records. The Chart.js library is loaded from a CDN, so charts require an internet connection.
